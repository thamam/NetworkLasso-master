# NetworkLasso

Code for "Network Lasso: Clustering and Optimization in Large Graphs", KDD 2015, (Hallac, Leskovec, Boyd)